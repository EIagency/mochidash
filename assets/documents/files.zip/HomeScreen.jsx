/**
 * HomeScreen — the uploaded design, ported to React Native.
 *
 * expo install expo-battery react-native-svg @expo-google-fonts/dm-sans
 *              @expo-google-fonts/nunito expo-font expo-keep-awake
 *
 * Icons: the design used @iconify/react with the Solar set, which is web-only.
 * Install react-native-svg and paste the five SVGs from the zip into
 * ./icons/index.jsx as SvgXml strings, or `npx expo install solar-icon-set`.
 * Placeholder <Icon> below just draws a dot so the layout runs today.
 */

import { useEffect, useState } from 'react';
import {
  Pressable,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import * as Battery from 'expo-battery';
import { useKeepAwake } from 'expo-keep-awake';

import MochiFace, { EXPRESSION_LABELS } from './MochiFace';
import { useSpeedCameras } from './useSpeedCameras';
import { color, radius, ring, shadow, font } from './theme';

const TOTAL_EXPRESSIONS = 80;
const EXPRESSION_INDEX = Object.keys(EXPRESSION_LABELS);

export default function HomeScreen({ name = 'Nevzat' }) {
  useKeepAwake();

  const [paused, setPaused] = useState(false);
  const [muted, setMuted] = useState(false);
  const [expression, setExpression] = useState('idle');
  const [battery, setBattery] = useState(null);
  const [now, setNow] = useState(new Date());

  const { warning, speedMph } = useSpeedCameras({ enabled: !paused });

  useEffect(() => {
    Battery.getBatteryLevelAsync().then(setBattery);
    const sub = Battery.addBatteryLevelListener(({ batteryLevel }) =>
      setBattery(batteryLevel)
    );
    return () => sub.remove();
  }, []);

  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 20000);
    return () => clearInterval(t);
  }, []);

  const batteryPct = battery == null ? null : Math.round(battery * 100);
  const label = EXPRESSION_LABELS[expression] ?? 'resting mochi';
  const index = Math.max(EXPRESSION_INDEX.indexOf(expression), 0) + 1;

  return (
    <SafeAreaView style={s.screen} edges={['top']}>
      <StatusBar barStyle="dark-content" />
      <ScrollView
        contentContainerStyle={s.container}
        showsVerticalScrollIndicator={false}
      >
        <View style={s.header}>
          <View>
            <Text style={s.eyebrow}>MOCHI COMPANION</Text>
            <Text style={s.title}>
              Hi, {name} <Text style={{ color: color.primary }}>✦</Text>
            </Text>
          </View>
          <Pressable
            style={s.iconButton}
            accessibilityLabel="Settings"
            onPress={() => setMuted((m) => !m)}
          >
            <Icon tint={color.mutedForeground} />
          </Pressable>
        </View>

        <View style={s.stageCard}>
          <View style={s.accentBlob} />

          <View style={s.stageHeader}>
            <View>
              <View style={s.liveRow}>
                <View
                  style={[
                    s.liveDot,
                    { backgroundColor: paused ? color.mutedForeground : color.primary },
                  ]}
                />
                <Text style={s.liveLabel}>
                  {paused ? 'PAUSED' : 'LIVE COMPANION'}
                </Text>
              </View>
              <Text style={s.stageSub}>
                {paused
                  ? 'Mochi is having a nap'
                  : warning
                  ? `Camera in ${warning.distance} m`
                  : 'Mochi is feeling peachy'}
              </Text>
            </View>
            <Pressable
              style={s.pauseButton}
              accessibilityLabel={paused ? 'Resume companion' : 'Pause companion'}
              onPress={() => setPaused((p) => !p)}
            >
              <Icon tint={color.primary} />
            </Pressable>
          </View>

          <MochiFace
            paused={paused}
            muted={muted}
            cameraWarning={warning}
            onExpression={setExpression}
          />

          <View style={s.chipRow}>
            <View style={s.chip}>
              <Text style={s.chipText}>{label}</Text>
            </View>
            <Text style={s.chipMeta}>
              • {index} of {TOTAL_EXPRESSIONS}
            </Text>
          </View>
        </View>

        <View style={s.tileRow}>
          <View style={s.tile}>
            <View style={s.tileHeader}>
              <Text style={s.tileLabel}>Phone battery</Text>
              <Icon tint={color.primary} />
            </View>
            <Text style={s.tileValue}>
              {batteryPct ?? '—'}
              <Text style={s.tileUnit}>%</Text>
            </Text>
            <View style={s.track}>
              <View
                style={[
                  s.trackFill,
                  { width: `${batteryPct ?? 0}%` },
                  batteryPct != null &&
                    batteryPct < 20 && { backgroundColor: color.destructive },
                ]}
              />
            </View>
          </View>

          <View style={s.tile}>
            <View style={s.tileHeader}>
              <Text style={s.tileLabel}>{speedMph > 1 ? 'Speed' : 'Today'}</Text>
              <Icon tint={color.mutedForeground} />
            </View>
            {speedMph > 1 ? (
              <>
                <Text style={s.tileValue}>
                  {Math.round(speedMph)}
                  <Text style={s.tileUnit}> mph</Text>
                </Text>
                <Text style={s.tileMeta}>GPS</Text>
              </>
            ) : (
              <>
                <Text style={s.tileValue}>
                  {now.toLocaleTimeString('en-GB', {
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                </Text>
                <Text style={s.tileMeta}>
                  {now.toLocaleDateString('en-GB', {
                    weekday: 'short',
                    day: 'numeric',
                    month: 'long',
                    year: 'numeric',
                  })}
                </Text>
              </>
            )}
          </View>
        </View>

        <AlertCard warning={warning} />
      </ScrollView>
    </SafeAreaView>
  );
}

/**
 * The "Next turn" slot from the design, doubling as the camera warning.
 * A live camera takes the card over — same shape, alarmed palette — so
 * the warning lands where your eye already is instead of as a new banner.
 */
function AlertCard({ warning }) {
  const isCamera = Boolean(warning);
  const urgent = warning?.speeding || warning?.level === 3;

  return (
    <View
      style={[
        s.alertCard,
        isCamera && {
          backgroundColor: urgent ? '#FFF1F1' : color.card,
          borderColor: urgent ? color.destructive : color.border,
        },
      ]}
    >
      <View
        style={[
          s.alertIcon,
          isCamera && {
            backgroundColor: urgent ? color.destructive : color.accent,
          },
        ]}
      >
        <Icon tint={urgent ? '#FFFFFF' : color.accentForeground} />
      </View>

      <View style={s.alertBody}>
        <View style={s.alertHeader}>
          <Text style={s.alertTitle}>
            {isCamera ? 'Speed camera' : 'Next turn'}
          </Text>
          <Text
            style={[
              s.alertDistance,
              urgent && { color: color.destructive },
            ]}
          >
            {isCamera ? `${warning.distance} m` : '600 m'}
          </Text>
        </View>

        <Text style={s.alertDetail} numberOfLines={1}>
          {isCamera
            ? warning.speeding
              ? `You're over the ${warning.limitMph} limit`
              : warning.limitMph
              ? `${warning.limitMph} mph limit ahead`
              : 'Fixed camera ahead'
            : 'Turn right onto Atatürk Boulevard'}
        </Text>

        <View style={s.alertFooter}>
          <View style={s.alertPill}>
            <Text style={s.alertPillText}>
              {isCamera ? 'Ahead of you' : '12 min left'}
            </Text>
          </View>
          <Text style={s.alertSource}>
            {isCamera ? 'OpenStreetMap' : 'Google Maps'}
          </Text>
        </View>
      </View>
    </View>
  );
}

// Placeholder — swap for react-native-svg versions of the Solar icons.
function Icon({ tint = color.mutedForeground, size = 20 }) {
  return (
    <View
      style={{
        width: size,
        height: size,
        borderRadius: 999,
        borderWidth: 1.5,
        borderColor: tint,
      }}
    />
  );
}

const s = StyleSheet.create({
  screen: { flex: 1, backgroundColor: color.background },
  container: { paddingHorizontal: 20, paddingTop: 8, paddingBottom: 112 },

  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  eyebrow: {
    fontFamily: font.sansBold,
    fontSize: 11,
    letterSpacing: 2,
    color: color.mutedForeground,
  },
  title: {
    fontFamily: font.heading,
    fontSize: 30,
    marginTop: 4,
    letterSpacing: -0.5,
    color: color.foreground,
  },
  iconButton: {
    width: 44,
    height: 44,
    borderRadius: 999,
    backgroundColor: color.card,
    alignItems: 'center',
    justifyContent: 'center',
    ...ring,
    ...shadow.card,
  },

  stageCard: {
    marginTop: 24,
    borderRadius: radius.section,
    backgroundColor: color.secondary,
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 20,
    overflow: 'hidden',
    ...ring,
  },
  accentBlob: {
    position: 'absolute',
    right: -32,
    top: -40,
    width: 128,
    height: 128,
    borderRadius: 999,
    backgroundColor: color.accent,
    opacity: 0.6,
  },
  stageHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  liveRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  liveDot: { width: 10, height: 10, borderRadius: 999 },
  liveLabel: {
    fontFamily: font.sansBold,
    fontSize: 11,
    letterSpacing: 1.2,
    color: color.primary,
  },
  stageSub: {
    fontFamily: font.sans,
    fontSize: 13,
    marginTop: 4,
    color: color.mutedForeground,
  },
  pauseButton: {
    width: 40,
    height: 40,
    borderRadius: 999,
    backgroundColor: 'rgba(255,255,255,0.8)',
    alignItems: 'center',
    justifyContent: 'center',
  },

  chipRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  chip: {
    borderRadius: 999,
    backgroundColor: color.card,
    paddingHorizontal: 12,
    paddingVertical: 5,
  },
  chipText: {
    fontFamily: font.sansBold,
    fontSize: 12,
    color: color.secondaryForeground,
  },
  chipMeta: {
    fontFamily: font.sans,
    fontSize: 12,
    color: color.mutedForeground,
  },

  tileRow: { flexDirection: 'row', gap: 12, marginTop: 16 },
  tile: {
    flex: 1,
    borderRadius: radius['2xl'],
    backgroundColor: color.card,
    padding: 16,
    ...ring,
    ...shadow.card,
  },
  tileHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  tileLabel: {
    fontFamily: font.sansBold,
    fontSize: 12,
    color: color.mutedForeground,
  },
  tileValue: {
    fontFamily: font.heading,
    fontSize: 24,
    marginTop: 8,
    color: color.foreground,
  },
  tileUnit: { fontSize: 15 },
  tileMeta: {
    fontFamily: font.sans,
    fontSize: 12,
    color: color.mutedForeground,
  },
  track: {
    height: 6,
    borderRadius: 999,
    backgroundColor: color.muted,
    marginTop: 8,
    overflow: 'hidden',
  },
  trackFill: { height: 6, borderRadius: 999, backgroundColor: color.primary },

  alertCard: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 16,
    borderRadius: radius['2xl'],
    backgroundColor: color.card,
    padding: 16,
    ...ring,
    ...shadow.card,
  },
  alertIcon: {
    width: 40,
    height: 40,
    borderRadius: radius.md,
    backgroundColor: color.accent,
    alignItems: 'center',
    justifyContent: 'center',
  },
  alertBody: { flex: 1, minWidth: 0 },
  alertHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  alertTitle: {
    fontFamily: font.heading,
    fontSize: 16,
    color: color.foreground,
  },
  alertDistance: {
    fontFamily: font.sansBold,
    fontSize: 12,
    color: color.primary,
  },
  alertDetail: {
    fontFamily: font.sans,
    fontSize: 13,
    marginTop: 2,
    color: color.mutedForeground,
  },
  alertFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 12,
  },
  alertPill: {
    borderRadius: 999,
    backgroundColor: color.secondary,
    paddingHorizontal: 10,
    paddingVertical: 4,
  },
  alertPillText: {
    fontFamily: font.sansBold,
    fontSize: 12,
    color: color.secondaryForeground,
  },
  alertSource: {
    fontFamily: font.sans,
    fontSize: 12,
    color: color.mutedForeground,
  },
});
