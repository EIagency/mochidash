// theme.js — tokens ported from globals.css.
//
// Two things don't survive the crossing to React Native:
//
// 1. corner-shape: squircle. RN only does circular corners, so the 2.5×
//    radius multiplier is dropped — squircles need a bigger radius to look
//    equal, plain rounded corners don't. Base values used directly.
// 2. blur(). The ground shadow under Mochi is a flat low-opacity ellipse
//    instead of a blurred one. Add expo-blur if you want the real thing.

export const color = {
  background: '#FFF9F3',
  foreground: '#332B2B',
  primary: '#F47F78',
  primaryShadow: '#D96662', // the hard drop under the blob
  primaryForeground: '#FFFFFF',
  secondary: '#F1E8E1',
  secondaryForeground: '#5D5150',
  muted: '#EAE1DB',
  mutedForeground: '#897B77',
  accent: '#FFD9D2',
  accentForeground: '#6B3935',
  destructive: '#D85D5D',
  card: '#FFFFFF',
  border: '#E9DDD5',
  chart2: '#F6B36A',
  chart3: '#88C9B5',
};

export const radius = {
  xs: 6,
  sm: 10,
  md: 12,
  lg: 14,
  xl: 18,
  '2xl': 22,
  '3xl': 30,
  section: 24,
  pill: 999,
};

export const font = {
  sans: 'DMSans_400Regular',
  sansMedium: 'DMSans_500Medium',
  sansBold: 'DMSans_700Bold',
  heading: 'Nunito_800ExtraBold',
};

// expo install @expo-google-fonts/dm-sans @expo-google-fonts/nunito expo-font
export const fontMap = {
  // import { DMSans_400Regular, ... } from '@expo-google-fonts/dm-sans';
  // import { Nunito_800ExtraBold } from '@expo-google-fonts/nunito';
};

export const shadow = {
  card: {
    shadowColor: '#8A6A5E',
    shadowOpacity: 0.06,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
    elevation: 2,
  },
  blob: {
    shadowColor: '#F47F78',
    shadowOpacity: 0.25,
    shadowRadius: 20,
    shadowOffset: { width: 0, height: 14 },
    elevation: 6,
  },
};

// ring-1 ring-border
export const ring = { borderWidth: 1, borderColor: color.border };
