/**
 * useSpeedCameras — warns when you're approaching a speed camera that's
 * actually ahead of you, not one on the opposite carriageway.
 *
 * expo install expo-location
 *
 * app.json needs:
 *   ios.infoPlist.NSLocationWhenInUseUsageDescription
 *   android.permissions: ["ACCESS_FINE_LOCATION"]
 *
 * Camera data comes from OpenStreetMap via your Convex cache (convex/cameras.ts),
 * so devices never hit Overpass directly.
 */

import { useEffect, useMemo, useRef, useState } from 'react';
import * as Location from 'expo-location';
import { useAction, useQuery } from 'convex/react';
import { api } from '../convex/_generated/api';

const MS_TO_MPH = 2.23694;

// Distance bands, metres. Each camera fires each band at most once per pass.
const BANDS = [
  { id: 'far', metres: 600, level: 1 },
  { id: 'near', metres: 300, level: 2 },
  { id: 'now', metres: 140, level: 3 },
];

const CONE_DEGREES = 55;   // camera must be roughly ahead of you
const MIN_SPEED_MS = 3;    // below ~7mph GPS heading is noise
const REARM_METRES = 900;  // re-arm a camera once you're this far past it

export function useSpeedCameras({ enabled = true } = {}) {
  const [position, setPosition] = useState(null);
  const [tiles, setTiles] = useState([]);
  const [warning, setWarning] = useState(null); // { camera, distance, level }
  const [permission, setPermission] = useState('pending');

  const ensureTiles = useAction(api.cameras.ensureTiles);
  const cameras = useQuery(api.cameras.inTiles, tiles.length ? { tiles } : 'skip');

  const fired = useRef({});     // osmId -> Set of band ids already fired
  const lastTileKey = useRef(null);

  // --- location stream -----------------------------------------------------
  useEffect(() => {
    if (!enabled) return;
    let sub;

    (async () => {
      const { status } = await Location.requestForegroundPermissionsAsync();
      setPermission(status);
      if (status !== 'granted') return;

      sub = await Location.watchPositionAsync(
        {
          accuracy: Location.Accuracy.High,
          timeInterval: 1000,
          distanceInterval: 5,
        },
        (loc) => setPosition(loc.coords)
      );
    })();

    return () => sub?.remove();
  }, [enabled]);

  // --- pull the 3x3 tile block around you, only when you cross a tile ------
  useEffect(() => {
    if (!position) return;
    const key = tileKey(position.latitude, position.longitude);
    if (key === lastTileKey.current) return;
    lastTileKey.current = key;

    const block = neighbourTiles(position.latitude, position.longitude);
    setTiles(block);
    ensureTiles({ tiles: block }).catch(() => {
      // offline or Overpass down — we still use whatever's cached
    });
  }, [position, ensureTiles]);

  // --- proximity check -----------------------------------------------------
  useEffect(() => {
    if (!position || !cameras?.length) return;

    const speedMs = Math.max(position.speed ?? 0, 0);
    const heading =
      speedMs > MIN_SPEED_MS && position.heading >= 0 ? position.heading : null;

    let best = null;

    for (const cam of cameras) {
      const d = haversine(
        position.latitude,
        position.longitude,
        cam.lat,
        cam.lon
      );

      const seen = fired.current[cam.osmId];
      if (d > REARM_METRES && seen) {
        delete fired.current[cam.osmId];
        continue;
      }
      if (d > BANDS[0].metres) continue;

      // Directional filter. With no usable heading (crawling, stationary)
      // we let it through rather than miss a warning.
      if (heading !== null) {
        const bearing = bearingTo(
          position.latitude,
          position.longitude,
          cam.lat,
          cam.lon
        );
        if (angleDelta(heading, bearing) > CONE_DEGREES) continue;
      }

      const band = BANDS.find((b) => d <= b.metres);
      if (!band) continue;

      const alreadyFired = fired.current[cam.osmId];
      if (alreadyFired?.has(band.id)) continue;

      if (!best || band.level > best.level) {
        best = { camera: cam, distance: Math.round(d), level: band.level, band };
      }
    }

    if (best) {
      fired.current[best.camera.osmId] =
        fired.current[best.camera.osmId] ?? new Set();
      fired.current[best.camera.osmId].add(best.band.id);

      setWarning({
        camera: best.camera,
        distance: best.distance,
        level: best.level,
        limitMph: best.camera.maxspeedMph ?? null,
        speeding:
          best.camera.maxspeedMph != null &&
          speedMs * MS_TO_MPH > best.camera.maxspeedMph + 2,
        at: Date.now(),
      });
    }
  }, [position, cameras]);

  // clear the warning after a few seconds so the UI can settle
  useEffect(() => {
    if (!warning) return;
    const t = setTimeout(() => setWarning(null), 5000);
    return () => clearTimeout(t);
  }, [warning]);

  const speedMph = useMemo(
    () => (position?.speed > 0 ? position.speed * MS_TO_MPH : 0),
    [position]
  );

  return {
    warning,
    speedMph,
    permission,
    cameraCount: cameras?.length ?? 0,
  };
}

// --- geo helpers -----------------------------------------------------------

const TILE = 0.1; // degrees, roughly 11km N-S

export function tileKey(lat, lon) {
  return `${Math.floor(lat / TILE)}:${Math.floor(lon / TILE)}`;
}

function neighbourTiles(lat, lon) {
  const out = [];
  for (let dy = -1; dy <= 1; dy++) {
    for (let dx = -1; dx <= 1; dx++) {
      out.push(tileKey(lat + dy * TILE, lon + dx * TILE));
    }
  }
  return out;
}

function haversine(lat1, lon1, lat2, lon2) {
  const R = 6371000;
  const p = Math.PI / 180;
  const dLat = (lat2 - lat1) * p;
  const dLon = (lon2 - lon1) * p;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1 * p) * Math.cos(lat2 * p) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}

function bearingTo(lat1, lon1, lat2, lon2) {
  const p = Math.PI / 180;
  const y = Math.sin((lon2 - lon1) * p) * Math.cos(lat2 * p);
  const x =
    Math.cos(lat1 * p) * Math.sin(lat2 * p) -
    Math.sin(lat1 * p) * Math.cos(lat2 * p) * Math.cos((lon2 - lon1) * p);
  return (Math.atan2(y, x) / p + 360) % 360;
}

function angleDelta(a, b) {
  const d = Math.abs(a - b) % 360;
  return d > 180 ? 360 - d : d;
}
