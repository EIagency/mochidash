// convex/cameras.ts
//
// Caches OpenStreetMap speed camera nodes per 0.1° tile so devices never hit
// Overpass directly. Overpass rate-limits aggressively and will block an app
// that queries from every handset.
//
// schema.ts:
//
//   cameras: defineTable({
//     osmId: v.string(),
//     tile: v.string(),
//     lat: v.number(),
//     lon: v.number(),
//     maxspeedMph: v.optional(v.number()),
//     direction: v.optional(v.string()),
//   }).index("by_tile", ["tile"]).index("by_osmId", ["osmId"]),
//
//   cameraTiles: defineTable({
//     tile: v.string(),
//     fetchedAt: v.number(),
//   }).index("by_tile", ["tile"]),

import { v } from "convex/values";
import { action, internalMutation, internalQuery, query } from "./_generated/server";
import { internal } from "./_generated/api";

const TILE = 0.1;
const STALE_MS = 1000 * 60 * 60 * 24 * 30; // refresh a tile monthly
const OVERPASS = "https://overpass-api.de/api/interpreter";

export const inTiles = query({
  args: { tiles: v.array(v.string()) },
  handler: async (ctx, { tiles }) => {
    const results = await Promise.all(
      tiles.map((tile) =>
        ctx.db
          .query("cameras")
          .withIndex("by_tile", (q) => q.eq("tile", tile))
          .collect()
      )
    );
    return results.flat();
  },
});

export const staleTiles = internalQuery({
  args: { tiles: v.array(v.string()) },
  handler: async (ctx, { tiles }) => {
    const cutoff = Date.now() - STALE_MS;
    const out: string[] = [];
    for (const tile of tiles) {
      const row = await ctx.db
        .query("cameraTiles")
        .withIndex("by_tile", (q) => q.eq("tile", tile))
        .unique();
      if (!row || row.fetchedAt < cutoff) out.push(tile);
    }
    return out;
  },
});

export const ensureTiles = action({
  args: { tiles: v.array(v.string()) },
  handler: async (ctx, { tiles }) => {
    const missing: string[] = await ctx.runQuery(internal.cameras.staleTiles, {
      tiles,
    });

    for (const tile of missing) {
      try {
        const cameras = await fetchTile(tile);
        await ctx.runMutation(internal.cameras.saveTile, { tile, cameras });
      } catch {
        // leave the tile unmarked so we retry next time through
      }
    }

    return { fetched: missing.length };
  },
});

export const saveTile = internalMutation({
  args: {
    tile: v.string(),
    cameras: v.array(
      v.object({
        osmId: v.string(),
        lat: v.number(),
        lon: v.number(),
        maxspeedMph: v.optional(v.number()),
        direction: v.optional(v.string()),
      })
    ),
  },
  handler: async (ctx, { tile, cameras }) => {
    const existing = await ctx.db
      .query("cameras")
      .withIndex("by_tile", (q) => q.eq("tile", tile))
      .collect();
    for (const row of existing) await ctx.db.delete(row._id);

    for (const cam of cameras) {
      await ctx.db.insert("cameras", { ...cam, tile });
    }

    const marker = await ctx.db
      .query("cameraTiles")
      .withIndex("by_tile", (q) => q.eq("tile", tile))
      .unique();
    if (marker) await ctx.db.patch(marker._id, { fetchedAt: Date.now() });
    else await ctx.db.insert("cameraTiles", { tile, fetchedAt: Date.now() });
  },
});

async function fetchTile(tile: string) {
  const [ty, tx] = tile.split(":").map(Number);
  const south = ty * TILE;
  const west = tx * TILE;
  const north = south + TILE;
  const east = west + TILE;

  const q = `[out:json][timeout:30];
(
  node["highway"="speed_camera"](${south},${west},${north},${east});
  node["enforcement"="maxspeed"](${south},${west},${north},${east});
);
out body;`;

  const res = await fetch(OVERPASS, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: `data=${encodeURIComponent(q)}`,
  });
  if (!res.ok) throw new Error(`overpass ${res.status}`);

  const json = await res.json();
  const seen = new Set<string>();

  return (json.elements ?? [])
    .filter((el: any) => el.type === "node" && el.lat && el.lon)
    .filter((el: any) => {
      const id = String(el.id);
      if (seen.has(id)) return false;
      seen.add(id);
      return true;
    })
    .map((el: any) => ({
      osmId: String(el.id),
      lat: el.lat,
      lon: el.lon,
      maxspeedMph: parseMaxspeed(el.tags?.maxspeed),
      direction: el.tags?.direction ?? undefined,
    }));
}

// OSM gives "30 mph" in the UK, bare numbers (km/h) most other places.
function parseMaxspeed(raw?: string): number | undefined {
  if (!raw) return undefined;
  const n = parseFloat(raw);
  if (Number.isNaN(n)) return undefined;
  return raw.includes("mph") ? n : Math.round(n * 0.621371);
}
