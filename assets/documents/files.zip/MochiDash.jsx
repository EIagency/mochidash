/**
 * MochiDash — a dash-mounted mochi companion that reacts to how you drive.
 *
 * expo install expo-sensors expo-audio expo-haptics expo-keep-awake react-native-reanimated
 *
 * Drop sound files in ./assets/sfx/ (see SFX below). Missing files just fail
 * silently, so you can run it faceless-audio first and add sounds later.
 *
 * Mount assumption: phone portrait, screen facing the driver, in a vent/dash
 * mount. If your mount is different, flip the signs in AXIS.
 */

import { useCallback, useEffect, useRef, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { DeviceMotion } from 'expo-sensors';
import * as Haptics from 'expo-haptics';
import { useKeepAwake } from 'expo-keep-awake';
import { useAudioPlayer } from 'expo-audio';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  withTiming,
} from 'react-native-reanimated';

const G = 9.80665;

// Which device axis maps to which car axis, and which way is positive.
// lat+ = car turning left (mochi thrown right), lon+ = accelerating.
const AXIS = {
  lat: { key: 'x', sign: -1 },
  lon: { key: 'z', sign: 1 },
  vert: { key: 'y', sign: 1 },
};

const TH = {
  accel: 0.22,      // g, throttle
  brake: -0.28,     // g, braking
  corner: 0.3,      // g, lateral
  bump: 0.55,       // g, vertical jolt
  hard: 0.6,        // g, "that was spicy" tier
};

const SPRING = { damping: 11, stiffness: 190, mass: 0.7 };

const SFX = {
  accel: require('./assets/sfx/mochi-go.mp3'),
  brake: require('./assets/sfx/mochi-woah.mp3'),
  corner: require('./assets/sfx/mochi-yeee.mp3'),
  bump: require('./assets/sfx/mochi-ough.mp3'),
  idle: require('./assets/sfx/mochi-mochi.mp3'),
};

const COLOURWAYS = {
  boostBlue: { body: '#EDEAE2', shell: '#2C6BE0', glow: '#7FB2FF' },
  racerRed: { body: '#EDEAE2', shell: '#D42A2A', glow: '#FF7A6E' },
  midnight: { body: '#E4E1D8', shell: '#171719', glow: '#5A5A62' },
  sakura: { body: '#F6EDEE', shell: '#E88CA8', glow: '#FFC2D4' },
};

export default function MochiDash({ colourway = 'boostBlue' }) {
  useKeepAwake();
  const c = COLOURWAYS[colourway] ?? COLOURWAYS.boostBlue;

  const [face, setFace] = useState('idle');
  const [showHud, setShowHud] = useState(false);
  const [muted, setMuted] = useState(false);
  const [g, setG] = useState({ lat: 0, lon: 0, vert: 0 });

  // Continuous physics — these drive the squish, never React state.
  const lean = useSharedValue(0);   // px, sideways throw
  const pitch = useSharedValue(0);  // px, fore/aft throw
  const squashX = useSharedValue(1);
  const squashY = useSharedValue(1);
  const tilt = useSharedValue(0);   // deg
  const eyeShift = useSharedValue(0);

  const gravity = useRef({ x: 0, y: 0, z: 0 });
  const settled = useRef(0);
  const holdUntil = useRef(0);
  const lastSfx = useRef({});
  const nextIdle = useRef(Date.now() + 6000);

  const players = {
    accel: useAudioPlayer(SFX.accel),
    brake: useAudioPlayer(SFX.brake),
    corner: useAudioPlayer(SFX.corner),
    bump: useAudioPlayer(SFX.bump),
    idle: useAudioPlayer(SFX.idle),
  };

  const play = useCallback(
    (key, cooldown = 2500) => {
      if (muted) return;
      const now = Date.now();
      if (now - (lastSfx.current[key] ?? 0) < cooldown) return;
      lastSfx.current[key] = now;
      try {
        players[key].seekTo(0);
        players[key].play();
      } catch (e) {
        // sound file not present yet — carry on
      }
    },
    [muted]
  );

  const setFaceFor = useCallback((next, ms, priority = 1) => {
    const now = Date.now();
    if (now < holdUntil.current && priority < 2) return;
    holdUntil.current = now + ms;
    setFace(next);
  }, []);

  const recalibrate = useCallback(() => {
    settled.current = 0;
    gravity.current = { x: 0, y: 0, z: 0 };
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
  }, []);

  useEffect(() => {
    DeviceMotion.setUpdateInterval(1000 / 50);

    const sub = DeviceMotion.addListener((data) => {
      const raw = data.accelerationIncludingGravity;
      if (!raw) return;

      // Low-pass to track which way is down, then subtract it. Works on every
      // device, unlike data.acceleration which is null on plenty of Androids.
      const a = settled.current < 40 ? 0.2 : 0.02;
      settled.current += 1;
      const gr = gravity.current;
      gr.x += a * (raw.x - gr.x);
      gr.y += a * (raw.y - gr.y);
      gr.z += a * (raw.z - gr.z);
      if (settled.current < 40) return; // still finding level

      const dyn = { x: raw.x - gr.x, y: raw.y - gr.y, z: raw.z - gr.z };
      const lat = (dyn[AXIS.lat.key] * AXIS.lat.sign) / G;
      const lon = (dyn[AXIS.lon.key] * AXIS.lon.sign) / G;
      const vert = (dyn[AXIS.vert.key] * AXIS.vert.sign) / G;

      setG({ lat, lon, vert });

      const clamp = (v, m) => Math.max(-m, Math.min(m, v));
      lean.value = withSpring(clamp(lat * 90, 46), SPRING);
      tilt.value = withSpring(clamp(lat * -16, 11), SPRING);
      pitch.value = withSpring(clamp(-lon * 40, 24), SPRING);
      eyeShift.value = withSpring(clamp(lat * 26, 13), SPRING);
      squashX.value = withSpring(1 + clamp(Math.abs(lon) * 0.3, 0.22), SPRING);
      squashY.value = withSpring(1 - clamp(Math.abs(lon) * 0.26, 0.2), SPRING);

      const now = Date.now();

      if (Math.abs(vert) > TH.bump) {
        setFaceFor('bump', 700, 2);
        play('bump', 1800);
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      } else if (lon < TH.brake) {
        setFaceFor(lon < -TH.hard ? 'panic' : 'brace', 900);
        play('brake');
      } else if (Math.abs(lat) > TH.corner) {
        setFaceFor(Math.abs(lat) > TH.hard ? 'send' : 'lean', 900);
        play('corner');
      } else if (lon > TH.accel) {
        setFaceFor(lon > TH.hard ? 'grin' : 'happy', 900);
        play('accel');
      } else if (now > holdUntil.current) {
        if (now > nextIdle.current) {
          nextIdle.current = now + 5000 + Math.random() * 9000;
          const pool = ['idle', 'blink', 'sleepy', 'happy', 'wink'];
          const pick = pool[Math.floor(Math.random() * pool.length)];
          setFaceFor(pick, pick === 'blink' ? 180 : 2200);
          if (pick === 'happy') play('idle', 20000);
        } else if (face !== 'idle' && face !== 'sleepy') {
          setFace('idle');
        }
      }
    });

    return () => sub.remove();
  }, [face, play, setFaceFor]);

  const bodyStyle = useAnimatedStyle(() => ({
    transform: [
      { translateX: lean.value },
      { translateY: pitch.value },
      { rotate: `${tilt.value}deg` },
      { scaleX: squashX.value },
      { scaleY: squashY.value },
    ],
  }));

  const eyeStyle = useAnimatedStyle(() => ({
    transform: [{ translateX: eyeShift.value }],
  }));

  return (
    <Pressable
      style={s.screen}
      onPress={() => setShowHud((v) => !v)}
      onLongPress={recalibrate}
    >
      <Animated.View style={[s.body, { backgroundColor: c.body }, bodyStyle]}>
        <View style={[s.shine, { backgroundColor: c.glow, opacity: 0.18 }]} />

        <Animated.View style={[s.faceRow, eyeStyle]}>
          <Eye face={face} side="left" />
          <Eye face={face} side="right" />
        </Animated.View>

        <View style={s.blushRow}>
          <View style={[s.blush, { backgroundColor: c.glow }]} />
          <View style={[s.blush, { backgroundColor: c.glow }]} />
        </View>

        <Animated.View style={eyeStyle}>
          <Mouth face={face} shell={c.shell} />
        </Animated.View>
      </Animated.View>

      {showHud && (
        <View style={s.hud}>
          <Meter label="Lateral" value={g.lat} shell={c.shell} />
          <Meter label="Long" value={g.lon} shell={c.shell} />
          <Meter label="Vertical" value={g.vert} shell={c.shell} />
          <Pressable onPress={() => setMuted((m) => !m)} hitSlop={12}>
            <Text style={s.hudAction}>{muted ? 'Turn sound on' : 'Mute'}</Text>
          </Pressable>
          <Text style={s.hudHint}>Hold anywhere to level the sensor</Text>
        </View>
      )}
    </Pressable>
  );
}

function Eye({ face, side }) {
  const flip = side === 'right' ? -1 : 1;

  if (face === 'blink' || (face === 'wink' && side === 'right')) {
    return <View style={[s.eyeBase, s.eyeClosed]} />;
  }
  if (face === 'happy' || face === 'grin' || face === 'send') {
    return <View style={[s.eyeBase, s.eyeArc]} />;
  }
  if (face === 'sleepy') {
    return <View style={[s.eyeBase, s.eyeSleepy]} />;
  }
  if (face === 'panic' || face === 'bump') {
    return (
      <View style={[s.eyeBase, s.eyeWide]}>
        <View style={s.pupilSmall} />
      </View>
    );
  }
  if (face === 'brace' || face === 'lean') {
    return (
      <View style={[s.eyeBase, s.eyeOval]}>
        <View style={[s.pupil, { transform: [{ translateX: 5 * flip }] }]} />
      </View>
    );
  }
  return (
    <View style={[s.eyeBase, s.eyeOval]}>
      <View style={s.pupil} />
    </View>
  );
}

function Mouth({ face, shell }) {
  const base = { backgroundColor: shell };
  switch (face) {
    case 'grin':
    case 'send':
      return <View style={[s.mouthOpenBig, base]} />;
    case 'happy':
      return <View style={[s.mouthSmile, { borderColor: shell }]} />;
    case 'panic':
      return <View style={[s.mouthOpenBig, base, { width: 62, height: 44 }]} />;
    case 'brace':
    case 'bump':
      return <View style={[s.mouthWave, { borderColor: shell }]} />;
    case 'lean':
      return <View style={[s.mouthSmall, base, { marginLeft: 26 }]} />;
    case 'sleepy':
      return <View style={[s.mouthSmall, base, { width: 16, height: 16 }]} />;
    default:
      return <View style={[s.mouthSmall, base]} />;
  }
}

function Meter({ label, value, shell }) {
  const pct = Math.min(Math.abs(value) / 1.0, 1);
  return (
    <View style={s.meterRow}>
      <Text style={s.meterLabel}>{label}</Text>
      <View style={s.meterTrack}>
        <View
          style={[
            s.meterFill,
            { width: `${pct * 100}%`, backgroundColor: shell },
          ]}
        />
      </View>
      <Text style={s.meterValue}>{value.toFixed(2)}g</Text>
    </View>
  );
}

const s = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#0A0A0C',
    alignItems: 'center',
    justifyContent: 'center',
  },
  body: {
    width: 240,
    height: 210,
    borderRadius: 86,
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: 18,
    overflow: 'hidden',
  },
  shine: {
    position: 'absolute',
    top: -50,
    left: -30,
    width: 200,
    height: 120,
    borderRadius: 100,
  },
  faceRow: { flexDirection: 'row', gap: 44 },
  eyeBase: { alignItems: 'center', justifyContent: 'center' },
  eyeOval: {
    width: 34,
    height: 42,
    borderRadius: 20,
    backgroundColor: '#141416',
  },
  eyeWide: {
    width: 42,
    height: 50,
    borderRadius: 24,
    backgroundColor: '#FFFFFF',
    borderWidth: 3,
    borderColor: '#141416',
  },
  eyeArc: {
    width: 40,
    height: 20,
    borderTopLeftRadius: 22,
    borderTopRightRadius: 22,
    backgroundColor: '#141416',
  },
  eyeSleepy: {
    width: 40,
    height: 18,
    borderBottomLeftRadius: 22,
    borderBottomRightRadius: 22,
    backgroundColor: '#141416',
  },
  eyeClosed: { width: 38, height: 6, borderRadius: 4, backgroundColor: '#141416' },
  pupil: { width: 12, height: 12, borderRadius: 6, backgroundColor: '#FFFFFF' },
  pupilSmall: { width: 12, height: 12, borderRadius: 6, backgroundColor: '#141416' },
  blushRow: { flexDirection: 'row', gap: 96, marginTop: 6 },
  blush: { width: 34, height: 16, borderRadius: 10, opacity: 0.5 },
  mouthSmall: {
    width: 24,
    height: 22,
    borderRadius: 12,
    marginTop: 8,
    alignSelf: 'center',
  },
  mouthOpenBig: {
    width: 50,
    height: 38,
    borderRadius: 24,
    marginTop: 6,
    alignSelf: 'center',
  },
  mouthSmile: {
    width: 52,
    height: 26,
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
    borderWidth: 5,
    borderTopWidth: 0,
    marginTop: 8,
    alignSelf: 'center',
  },
  mouthWave: {
    width: 56,
    height: 18,
    borderRadius: 10,
    borderWidth: 4,
    borderTopWidth: 0,
    borderLeftWidth: 0,
    marginTop: 10,
    alignSelf: 'center',
    transform: [{ rotate: '-4deg' }],
  },
  hud: {
    position: 'absolute',
    bottom: 40,
    left: 24,
    right: 24,
    gap: 10,
  },
  meterRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  meterLabel: { color: '#8A8A93', width: 62, fontSize: 12 },
  meterTrack: {
    flex: 1,
    height: 4,
    borderRadius: 2,
    backgroundColor: '#1E1E22',
    overflow: 'hidden',
  },
  meterFill: { height: 4, borderRadius: 2 },
  meterValue: { color: '#E8E8EE', width: 54, fontSize: 12, textAlign: 'right' },
  hudAction: { color: '#E8E8EE', fontSize: 13, marginTop: 4 },
  hudHint: { color: '#55555E', fontSize: 11 },
});
