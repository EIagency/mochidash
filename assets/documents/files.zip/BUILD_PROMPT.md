# MochiDash — build prompt

Paste this into your builder. Attach `theme.js`, `MochiFace.jsx`, `HomeScreen.jsx`,
`useSpeedCameras.js` and `cameras.ts` as reference — they are working reference
implementations, not final code. Follow their logic; improve their structure.

---

## What we're building

A dash-mounted phone companion for drivers. A squishy mochi character fills the
screen and physically reacts to how the car is being driven — it squashes under
braking, leans through corners, grins under throttle, and gets startled by
potholes. It also warns about speed cameras ahead.

The reference product is the Dasai Mochi 3, a physical LCD-faced toy from
Japanese street-car culture. This is the phone version: same warmth, no hardware.
Tone is playful and a bit rude, never cutesy-corporate. The character is the
product — everything else on screen is support.

## Stack

- Expo (SDK 52+) / React Native, TypeScript
- `react-native-reanimated` v3 for all continuous motion
- `expo-sensors`, `expo-location`, `expo-audio`, `expo-haptics`, `expo-battery`,
  `expo-keep-awake`
- `react-native-svg` for icons
- Convex for the backend (speed camera cache only — everything else is local)
- No state library. Component state and refs are enough.

## Screens

**Home** is the only screen for v1. Settings is a modal.

### Home layout, top to bottom

1. **Header** — eyebrow "MOCHI COMPANION" in tracked caps, then `Hi, {name} ✦`
   in the heading face. Settings button on the right, 44px circular, white,
   1px border.
2. **Stage card** — the hero. Warm beige (`--secondary`) rounded card with a
   soft peach circle bleeding off the top-right corner. Contains a live/paused
   indicator with a pulsing dot, a one-line status ("Mochi is feeling peachy"),
   a pause button, the mochi itself on a 192px-tall stage, and a chip below
   showing the current expression name and its index out of 80.
3. **Two tiles** — phone battery with a progress bar; clock and date that swaps
   to live GPS speed in mph once moving above walking pace.
4. **Alert card** — shows next turn by default. A live speed camera warning
   takes this card over: same shape, red palette when speeding. Do not add a
   separate warning banner.

## Design system

Port these exactly from `theme.js`. The palette is warm and soft — cream
background, coral character, no cold greys anywhere.

```
background #FFF9F3   foreground #332B2B   primary #F47F78
primaryShadow #D96662 (hard drop under the blob)
secondary #F1E8E1    muted #EAE1DB        mutedForeground #897B77
accent #FFD9D2       accentForeground #6B3935   destructive #D85D5D
card #FFFFFF         border #E9DDD5
```

Fonts: DM Sans for body, Nunito ExtraBold for headings and numbers. Load with
`@expo-google-fonts/*`, hold the splash until loaded.

Radii: cards 22, the stage card 26, pills 999. The original web design used
`corner-shape: squircle` with a 2.5× radius multiplier — **drop the multiplier**
when porting. It exists to make squircles read correctly; applied to RN's
circular corners it turns cards into pills.

The signature visual is a **hard offset shadow**, not a soft blur: a duplicate
shape in `#D96662` sitting 12px below the mochi body, 4px below each cheek. It
must live inside the same animated wrapper so it squashes with the body.

## The mochi character

**Body:** 144px, `borderRadius: 42%`, coral. Two cheek circles poking out either
side at -20px, rotated ±12°. A `✦` above the top-right. A flat 8%-opacity
ellipse on the ground beneath it.

**Face** is built from plain Views, no images — eyes and mouth swap shape by
expression:

| Expression | Trigger | Eyes | Mouth |
|---|---|---|---|
| `idle` | default | dots | small smile |
| `blink` | random, 180ms | closed bars | smile |
| `sleepy` | random / paused | downward arcs | tiny smile |
| `wink` | random | right eye closed | smile |
| `happy` | throttle > 0.22g | upward arcs | smile |
| `grin` | throttle > 0.6g | upward arcs | open oval |
| `brace` | braking < -0.28g | dots with glint | flat line |
| `panic` | braking < -0.6g, or speeding past a camera | wide outlined | big open |
| `lean` | lateral > 0.3g | dots shifted | smile shifted |
| `send` | lateral > 0.6g | upward arcs | open oval |
| `bump` | vertical > 0.55g | wide outlined | flat line |
| `alert` | camera warning | wide outlined | small open |

Ship at least 20 expressions. The physical toy advertises 70+ and the chip
counter says "of 80" — populate the idle pool generously so it stays surprising
on a long drive.

## Motion and physics

Read `DeviceMotion` at 50Hz. Critical detail: **do not use `data.acceleration`** —
it returns null on a lot of Android hardware. Use
`accelerationIncludingGravity`, track the gravity vector with a low-pass filter
(α 0.2 while settling for the first 40 samples, then 0.02), and subtract it.
Divide by 9.80665 for g. Ignore all readings during the settle window.

Assume a portrait vent mount, screen facing the driver: device X is lateral,
Z is longitudinal, Y is vertical. Put the axis mapping in a config object with
sign flags so other mount styles are a one-line change, and expose a
long-press to re-level.

Drive these from the sensor via shared values, all spring-damped
(`damping: 11, stiffness: 190, mass: 0.7`), all clamped:

- lateral g → horizontal throw (max 34px), tilt (max 10°), eye shift (max 10px)
- longitudinal g → fore/aft throw (max 18px), and squash: scaleX up to 1.2 while
  scaleY drops to 0.82

Expressions are React state, physics is Reanimated shared values. Never put
per-frame values through React state — it will drop frames on mid-range Android.

Hold each expression for its duration before another can replace it, with a
priority flag so bumps and camera warnings can interrupt. Idle expressions cycle
every 5–14 seconds at random.

## Sound

One-shot sfx per event via `expo-audio`, with a per-key cooldown (~2.5s) so
stop-start traffic doesn't turn into a machine gun. Missing files must fail
silently. Duck to nothing when muted. Respect the iOS silent switch by default
but let the user override it in settings — people mount this while playing music.

Haptics: light impact on bumps, warning notification on camera alerts.

## Speed cameras

Warn on approach to fixed cameras ahead, and flag if over the posted limit.

**Data:** OpenStreetMap `highway=speed_camera` and `enforcement=maxspeed` nodes,
pulled via Overpass. Cache server-side in Convex by 0.1° tile with a 30-day
refresh. **Devices must never hit Overpass directly** — it rate-limits hard and
will block the app. Client asks Convex for a 3×3 tile block and only refetches
when it crosses a tile boundary.

**Client logic:** watch position at 1s / 5m. Three distance bands — 600m, 300m,
140m — each firing at most once per camera per pass, re-arming at 900m past.
Filter to cameras roughly ahead using a ±55° bearing cone, but disable that
filter below ~7mph since GPS heading is noise at low speed. A spurious warning
in traffic beats a missed one.

Parse `maxspeed`: UK tags read "30 mph", most other countries are bare km/h.

**Known gaps to leave as TODOs, not silently ship:** average-speed zones are OSM
ways and relations rather than nodes and need separate handling; mobile camera
vans aren't in OSM at all.

**Legal:** camera warning apps are legal in the UK but banned in France, Germany
and Switzerland — Germany's ban covers a passenger operating it too. Geofence
the feature off in those countries. This is a store-rejection risk, not a
nice-to-have.

## Driver safety constraints

Non-negotiable, and they should shape the code, not be bolted on:

- No text the driver is expected to read while moving. Status lines are glanceable
  or they're decoration.
- No interaction required at any point during a drive. Every control is
  set-and-forget before setting off.
- Keep the screen awake, but dim the whole UI at night rather than blasting
  a coral blob into the windscreen reflection.
- Sound and haptics carry the camera warning. The visual is confirmation only.

## Settings modal

Colourway picker (Boost Blue, Racer Red, Midnight Black, Sakura Pink — the body
and its hard shadow recolour together), mute toggle, camera warnings on/off,
axis mapping / re-level, and a debug HUD toggle showing live lateral,
longitudinal and vertical g with a meter bar each.

## Acceptance

- Runs at 60fps on a mid-range Android with the debug HUD open.
- Mochi settles to centre within a second of a stationary start, and stays
  centred on a smooth motorway cruise — no drift, no phantom lean.
- A hard brake produces visible squash within ~100ms.
- Camera warning fires at 600m, and does not fire for a camera on the opposite
  carriageway at 70mph.
- Nothing crashes with sound files absent, location denied, or offline.

## Out of scope for v1

Accounts, drive history, leaderboards, sharing, OBD integration, custom
character uploads. Get the character feeling alive first — that is the whole
product, and everything else is a distraction until it's right.
