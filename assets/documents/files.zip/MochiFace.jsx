/**
 * MochiFace — the reactive blob, restyled to the peach design.
 *
 * Same accelerometer physics as before. What changed is the look: coral body,
 * hard offset shadow, side cheeks, sparkle. Reports its current expression up
 * via onExpression so the parent can label it.
 */

import { useCallback, useEffect, useRef, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { DeviceMotion } from 'expo-sensors';
import * as Haptics from 'expo-haptics';
import { useAudioPlayer } from 'expo-audio';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from 'react-native-reanimated';
import { color, radius } from './theme';

const G = 9.80665;

const AXIS = {
  lat: { key: 'x', sign: -1 },
  lon: { key: 'z', sign: 1 },
  vert: { key: 'y', sign: 1 },
};

const TH = { accel: 0.22, brake: -0.28, corner: 0.3, bump: 0.55, hard: 0.6 };
const SPRING = { damping: 11, stiffness: 190, mass: 0.7 };

// Shown in the chip under the blob.
export const EXPRESSION_LABELS = {
  idle: 'resting mochi',
  blink: 'quick blink',
  sleepy: 'sleepy squint',
  wink: 'cheeky wink',
  happy: 'happy bounce',
  grin: 'full send grin',
  brace: 'bracing',
  panic: 'wide eyes',
  lean: 'leaning in',
  send: 'sending it',
  bump: 'took a bump',
  alert: 'camera ahead',
};

const SFX = {
  accel: require('./assets/sfx/mochi-go.mp3'),
  brake: require('./assets/sfx/mochi-woah.mp3'),
  corner: require('./assets/sfx/mochi-yeee.mp3'),
  bump: require('./assets/sfx/mochi-ough.mp3'),
  idle: require('./assets/sfx/mochi-mochi.mp3'),
  camera: require('./assets/sfx/mochi-camera.mp3'),
};

export default function MochiFace({
  paused = false,
  muted = false,
  cameraWarning = null,
  onExpression,
}) {
  const [face, setFace] = useState('idle');

  const lean = useSharedValue(0);
  const pitch = useSharedValue(0);
  const squashX = useSharedValue(1);
  const squashY = useSharedValue(1);
  const tilt = useSharedValue(0);
  const eyeShift = useSharedValue(0);

  const gravity = useRef({ x: 0, y: 0, z: 0 });
  const settled = useRef(0);
  const holdUntil = useRef(0);
  const lastSfx = useRef({});
  const nextIdle = useRef(Date.now() + 6000);

  const players = {
    accel: useAudioPlayer(SFX.accel),
    brake: useAudioPlayer(SFX.brake),
    corner: useAudioPlayer(SFX.corner),
    bump: useAudioPlayer(SFX.bump),
    idle: useAudioPlayer(SFX.idle),
    camera: useAudioPlayer(SFX.camera),
  };

  const play = useCallback(
    (key, cooldown = 2500) => {
      if (muted) return;
      const now = Date.now();
      if (now - (lastSfx.current[key] ?? 0) < cooldown) return;
      lastSfx.current[key] = now;
      try {
        players[key].seekTo(0);
        players[key].play();
      } catch {}
    },
    [muted]
  );

  const setFaceFor = useCallback(
    (next, ms, priority = 1) => {
      const now = Date.now();
      if (now < holdUntil.current && priority < 2) return;
      holdUntil.current = now + ms;
      setFace(next);
      onExpression?.(next);
    },
    [onExpression]
  );

  // Camera warnings outrank everything the accelerometer has to say.
  useEffect(() => {
    if (!cameraWarning) return;
    setFaceFor(cameraWarning.speeding ? 'panic' : 'alert', 4000, 2);
    play('camera', 0);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
  }, [cameraWarning, play, setFaceFor]);

  useEffect(() => {
    if (paused) {
      lean.value = withSpring(0, SPRING);
      pitch.value = withSpring(0, SPRING);
      tilt.value = withSpring(0, SPRING);
      squashX.value = withSpring(1, SPRING);
      squashY.value = withSpring(1, SPRING);
      setFace('sleepy');
      return;
    }

    DeviceMotion.setUpdateInterval(1000 / 50);

    const sub = DeviceMotion.addListener((data) => {
      const raw = data.accelerationIncludingGravity;
      if (!raw) return;

      const a = settled.current < 40 ? 0.2 : 0.02;
      settled.current += 1;
      const gr = gravity.current;
      gr.x += a * (raw.x - gr.x);
      gr.y += a * (raw.y - gr.y);
      gr.z += a * (raw.z - gr.z);
      if (settled.current < 40) return;

      const dyn = { x: raw.x - gr.x, y: raw.y - gr.y, z: raw.z - gr.z };
      const lat = (dyn[AXIS.lat.key] * AXIS.lat.sign) / G;
      const lon = (dyn[AXIS.lon.key] * AXIS.lon.sign) / G;
      const vert = (dyn[AXIS.vert.key] * AXIS.vert.sign) / G;

      const clamp = (v, m) => Math.max(-m, Math.min(m, v));
      lean.value = withSpring(clamp(lat * 70, 34), SPRING);
      tilt.value = withSpring(clamp(lat * -14, 10), SPRING);
      pitch.value = withSpring(clamp(-lon * 30, 18), SPRING);
      eyeShift.value = withSpring(clamp(lat * 20, 10), SPRING);
      squashX.value = withSpring(1 + clamp(Math.abs(lon) * 0.28, 0.2), SPRING);
      squashY.value = withSpring(1 - clamp(Math.abs(lon) * 0.24, 0.18), SPRING);

      const now = Date.now();

      if (Math.abs(vert) > TH.bump) {
        setFaceFor('bump', 700, 2);
        play('bump', 1800);
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      } else if (lon < TH.brake) {
        setFaceFor(lon < -TH.hard ? 'panic' : 'brace', 900);
        play('brake');
      } else if (Math.abs(lat) > TH.corner) {
        setFaceFor(Math.abs(lat) > TH.hard ? 'send' : 'lean', 900);
        play('corner');
      } else if (lon > TH.accel) {
        setFaceFor(lon > TH.hard ? 'grin' : 'happy', 900);
        play('accel');
      } else if (now > holdUntil.current) {
        if (now > nextIdle.current) {
          nextIdle.current = now + 5000 + Math.random() * 9000;
          const pool = ['idle', 'blink', 'sleepy', 'happy', 'wink'];
          const pick = pool[Math.floor(Math.random() * pool.length)];
          setFaceFor(pick, pick === 'blink' ? 180 : 2200);
          if (pick === 'happy') play('idle', 20000);
        } else if (face !== 'idle' && face !== 'sleepy') {
          setFace('idle');
        }
      }
    });

    return () => sub.remove();
  }, [face, paused, play, setFaceFor]);

  const bodyStyle = useAnimatedStyle(() => ({
    transform: [
      { translateX: lean.value },
      { translateY: pitch.value },
      { rotate: `${tilt.value}deg` },
      { scaleX: squashX.value },
      { scaleY: squashY.value },
    ],
  }));

  const eyeStyle = useAnimatedStyle(() => ({
    transform: [{ translateX: eyeShift.value }],
  }));

  return (
    <View style={s.stage}>
      <View style={s.groundShadow} />

      <Animated.View style={[s.bodyWrap, bodyStyle]}>
        <View style={s.hardShadow} />
        <View style={[s.cheek, s.cheekLeft]}>
          <View style={s.cheekShadow} />
        </View>
        <View style={[s.cheek, s.cheekRight]}>
          <View style={s.cheekShadow} />
        </View>

        <View style={s.body}>
          <Animated.View style={[s.eyeRow, eyeStyle]}>
            <Eye face={face} side="left" />
            <Eye face={face} side="right" />
          </Animated.View>
          <Animated.View style={eyeStyle}>
            <Mouth face={face} />
          </Animated.View>
        </View>

        <Text style={s.sparkle}>✦</Text>
      </Animated.View>
    </View>
  );
}

function Eye({ face, side }) {
  const flip = side === 'right' ? -1 : 1;

  if (face === 'blink' || (face === 'wink' && side === 'right')) {
    return <View style={s.eyeClosed} />;
  }
  if (face === 'happy' || face === 'grin' || face === 'send') {
    return <View style={s.eyeArc} />;
  }
  if (face === 'sleepy') {
    return <View style={s.eyeSleepy} />;
  }
  if (face === 'panic' || face === 'bump' || face === 'alert') {
    return (
      <View style={s.eyeWide}>
        <View style={s.pupilSmall} />
      </View>
    );
  }
  if (face === 'brace' || face === 'lean') {
    return (
      <View style={s.eyeDot}>
        <View style={[s.glint, { transform: [{ translateX: 3 * flip }] }]} />
      </View>
    );
  }
  return <View style={s.eyeDot} />;
}

function Mouth({ face }) {
  switch (face) {
    case 'grin':
    case 'send':
      return <View style={s.mouthOpen} />;
    case 'panic':
      return <View style={[s.mouthOpen, { width: 42, height: 34 }]} />;
    case 'alert':
      return <View style={[s.mouthOpen, { width: 22, height: 26 }]} />;
    case 'brace':
    case 'bump':
      return <View style={s.mouthFlat} />;
    case 'lean':
      return <View style={[s.mouthSmile, { marginLeft: 22 }]} />;
    case 'sleepy':
      return <View style={[s.mouthSmile, { width: 26, height: 12 }]} />;
    default:
      return <View style={s.mouthSmile} />;
  }
}

const BODY = 144;

const s = StyleSheet.create({
  stage: {
    height: 192,
    alignItems: 'center',
    justifyContent: 'center',
  },
  groundShadow: {
    position: 'absolute',
    bottom: 12,
    width: 160,
    height: 20,
    borderRadius: 999,
    backgroundColor: color.foreground,
    opacity: 0.08,
  },
  bodyWrap: {
    width: BODY,
    height: BODY,
    alignItems: 'center',
    justifyContent: 'center',
  },
  hardShadow: {
    position: 'absolute',
    top: 12,
    left: 0,
    width: BODY,
    height: BODY,
    borderRadius: BODY * 0.42,
    backgroundColor: color.primaryShadow,
  },
  body: {
    width: BODY,
    height: BODY,
    borderRadius: BODY * 0.42,
    backgroundColor: color.primary,
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: 10,
  },
  cheek: {
    position: 'absolute',
    top: 80,
    width: 32,
    height: 32,
    borderRadius: 999,
    backgroundColor: color.primary,
    zIndex: 2,
  },
  cheekLeft: { left: -20, transform: [{ rotate: '-12deg' }] },
  cheekRight: { right: -20, transform: [{ rotate: '12deg' }] },
  cheekShadow: {
    position: 'absolute',
    top: 4,
    left: 0,
    width: 32,
    height: 32,
    borderRadius: 999,
    backgroundColor: color.primaryShadow,
    zIndex: -1,
  },
  sparkle: {
    position: 'absolute',
    top: -30,
    right: 4,
    fontSize: 24,
    color: color.chart2,
  },
  eyeRow: { flexDirection: 'row', gap: 40 },

  eyeDot: {
    width: 16,
    height: 16,
    borderRadius: 999,
    backgroundColor: color.foreground,
    alignItems: 'center',
    justifyContent: 'center',
  },
  eyeWide: {
    width: 22,
    height: 26,
    borderRadius: 999,
    backgroundColor: color.background,
    borderWidth: 3,
    borderColor: color.foreground,
    alignItems: 'center',
    justifyContent: 'center',
  },
  eyeArc: {
    width: 22,
    height: 11,
    borderTopLeftRadius: 12,
    borderTopRightRadius: 12,
    backgroundColor: color.foreground,
  },
  eyeSleepy: {
    width: 22,
    height: 10,
    borderBottomLeftRadius: 12,
    borderBottomRightRadius: 12,
    backgroundColor: color.foreground,
  },
  eyeClosed: {
    width: 20,
    height: 4,
    borderRadius: 3,
    backgroundColor: color.foreground,
  },
  pupilSmall: {
    width: 8,
    height: 8,
    borderRadius: 999,
    backgroundColor: color.foreground,
  },
  glint: {
    width: 5,
    height: 5,
    borderRadius: 999,
    backgroundColor: color.background,
  },

  mouthSmile: {
    width: 40,
    height: 20,
    borderBottomLeftRadius: 999,
    borderBottomRightRadius: 999,
    borderBottomWidth: 4,
    borderColor: color.foreground,
    marginTop: 18,
  },
  mouthOpen: {
    width: 34,
    height: 28,
    borderRadius: 999,
    backgroundColor: color.foreground,
    marginTop: 16,
  },
  mouthFlat: {
    width: 40,
    height: 4,
    borderRadius: 3,
    backgroundColor: color.foreground,
    marginTop: 26,
  },
});
